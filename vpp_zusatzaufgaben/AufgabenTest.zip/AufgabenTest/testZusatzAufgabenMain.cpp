// (c) KJR
#include "tst_testaufgaben.h"
#include "produktmitpreishistory.h"
#include "hochlager.h"
#include "a04.h"
#include <iostream>
#include <gtest/gtest.h>

using std::cout;
using std::endl;


int main(int argc, char *argv[])
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
